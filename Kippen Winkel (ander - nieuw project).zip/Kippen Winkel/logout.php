<?php
session_start();
session_destroy();

// Ensure no further code execution occurs after the header redirection
header("Location: login.php");
exit();
?>
