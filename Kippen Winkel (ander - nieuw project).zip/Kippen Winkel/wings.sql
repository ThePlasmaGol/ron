-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 15 apr 2024 om 11:29
-- Serverversie: 10.4.28-MariaDB
-- PHP-versie: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wings_project`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `wings`
--

CREATE TABLE `wings` (
  `id` int(99) NOT NULL,
  `hoeveel` int(99) NOT NULL,
  `name` varchar(255) NOT NULL,
  `prijs` decimal(5,2) NOT NULL,
  `foto` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `wings`
--

INSERT INTO `wings` (`id`, `hoeveel`, `name`, `prijs`, `foto`) VALUES
(1, 4, 'Chicken Tenders', 7.99, 'tenders.jpg'),
(2, 4, 'Air Fry Tenders', 5.99, 'frytenders.jpg'),
(7, 3, 'Taiwanese Chicken Tenders', 5.50, 'taiwantenders.webp');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `wings`
--
ALTER TABLE `wings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `wings`
--
ALTER TABLE `wings`
  MODIFY `id` int(99) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
